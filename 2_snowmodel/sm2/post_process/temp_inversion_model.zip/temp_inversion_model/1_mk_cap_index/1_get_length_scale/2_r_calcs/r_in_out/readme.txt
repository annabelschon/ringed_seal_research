This, coords_topo.dat, was copied from:

/data1/working/moose/calum_oldcrow/inversion_index/1_mk_cap_index/2_get_length_scale/1_mk_data_inputs/

