Run this with the command:

SnowMan -> Rscript 2_semivar_obs_script.r

